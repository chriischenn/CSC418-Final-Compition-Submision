#ifndef BPSECOND_H
#define BPSECOND_H
#include "Ray.h"
#include "Light.h"
#include "Object.h"
#include <Eigen/Core>
#include <vector>
#include <memory>


// Given a ray and its hit in the scene, return the Blinn-Phong shading
// contribution over all _visible_ light sources (e.g., take into account
// shadows).
//
// Inputs:
//   ray  incoming ray
//   hit_id  index into objects of the object just hit by ray
//   t  _parametric_ distance along ray to hit
//   n  unit surface normal at hit
//   objects  list of objects in the scene
//   lights  list of lights in the scene
// Returns shaded color collected by this ray as rgb 3-vector
Eigen::Vector3d bpsecond(
  const Ray & ray,
  const int & hit_id,
  const double & t,
  const Eigen::Vector3d & n,
  const Eigen::Vector3d & colour,
  const std::vector< std::shared_ptr<Object> > & objects,
  const std::vector<std::shared_ptr<Light> > & lights);

#endif
